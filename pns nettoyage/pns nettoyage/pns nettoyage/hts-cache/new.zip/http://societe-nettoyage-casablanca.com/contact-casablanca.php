<!doctype html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-144102185-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-144102185-2');
</script>

		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1">
		<meta name="keywords" content="Société de nettoyage à Casablanca Maroc PNS" />
		<meta name="description" content="Société de nettoyage à Casablanca Maroc PNS">
		<title>Société de nettoyage à Casablanca Maroc PNS</title>
		<link rel="icon" type="image/png" href="images/logo.png" sizes="16x16">
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400italic,400,600,600italic,700,800,800italic" rel="stylesheet" type="text/css">
		<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" type="text/css" media="all">
		<link rel="stylesheet" href="css/sliders/ios/style.css" type="text/css" media="all">
		<link rel="stylesheet" href="css/template.css" type="text/css" media="all">
		<link rel="stylesheet" href="css/responsive.css" type="text/css" media="all">
		<link rel="stylesheet" href="css/base-sizing.css" type="text/css" media="all">
		<link rel="stylesheet" href="css/custom.css" type="text/css" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
		<link rel="stylesheet" href="style.css.contact" />
		<script type="text/javascript" src="jas/modernizr.min.js"></script>
		<script type="text/javascript" src="jas/jquery.js"></script>
		<style type="text/css">
		    #ui-datepicker-div{ z-index: 999999999 !important;}
		    .dropdown-submenu { min-width: 250px;}
		</style>
	</head>
    <body class="">
        <div id="page_wrapper">
		    <header id="header" class="site-header style1 cta_button">
				<div class="kl-header-bg"></div>
				<div class="container siteheader-container" style="background-color: #11ffee00;">
					<div class="kl-top-header clearfix">
						<div class="header-links-container ">
						    <!--
							<ul class="topnav navRight topnav">
								<li>
									<a class="popup-with-form" href="#login_panel">
										<i class="glyphicon glyphicon-log-in visible-xs xs-icon"></i>
										<span class="hidden-xs">LOGIN</span>
									</a>
								</li>	
							</ul>
							-->
							<ul class="topnav navLeft topnav--lang">
								<li class="languages drop">
									<a href="#">
										<span class="globe glyphicon glyphicon-globe icon-white xs-icon"></span>
										<span class="hidden-xs">LANGUAGES</span>
									</a>
									<div class="pPanel">
										<ul class="inner">
											<li class="toplang-item">
												<a href="#">
													<img src="images/fr.png" alt="Français" class="toplang-flag"> Français
												</a>
											</li>
										</ul>
									</div>
								</li>
							</ul>
							<div id="search" class="header-search">
								<a href="#" class="searchBtn "><span class="glyphicon glyphicon-search icon-white"></span></a>
								<div class="search-container">
									<form id="searchform" class="header-searchform" action="#" method="get" target="_blank">
									    <input type="hidden" id="q" name="q"/>
										<input name="s" maxlength="20" class="inputbox" type="text" size="20" value="SEARCH ..." onblur="if (this.value=='') this.value='SEARCH ...';" onfocus="if (this.value=='SEARCH ...') this.value='';">
										<button type="submit" id="searchsubmit" class="searchsubmit glyphicon glyphicon-search icon-white"></button>
									</form>
								</div>
							</div>
					    </div>
						<div class="header-leftside-container ">
							<ul class="social-icons sc--clean topnav navRight">
								<li><a href="#" target="_self" class="icon-facebook" title="Facebook"></a></li>
								<li><a href="#" target="_self" class="icon-twitter" title="Twitter"></a></li>	
								<li><a href="#" target="_self" class="icon-pinterest" title="Pinterest"></a></li>
								<li><a href="#" target="_blank" class="icon-gplus" title="Google Plus"></a></li>
							</ul>
							<div class="clearfix visible-xxs">
							</div>
							<span class="kl-header-toptext" style="font-size: 18px;font-weight: bold;color: #70b946;">Société de nettoyage à Casablanca Maroc ---
							   <a href="#" class="fw-bold" style="font-size: 18px;font-weight: bold;color: #1983c5;">0606-383-858 / 0668-311-925</a>
							</span>
						</div>
				    </div>
				    <div class="separator"></div>
					<div class="logo-container hasInfoCard logosize--yes">
						<h1 class="site-logo logo" id="logo">
							<a href="http://societe-nettoyage-casablanca.com/" title="">
								<img src="images/logo.png" class="logo-img" alt="Nettoyage casablanca" title="Société de nettoyage à Casablanca maroc " />
							</a>
						</h1>
						<div id="infocard" class="logo-infocard" style="background: #fafafa;color: black;padding: 5px 20px;">
							<div class="custom">
								<div class="row">
									<div class="col-sm-5">
										<p style="text-align: center;">
											<img src="images/logo.png" class="" alt="société de Nettoyage à casablanca Maroc" title="société de Nettoyage à casablanca Maroc" />
										</p>
										<ul class="social-icons sc--clean"  style="text-align: center;">
											<li><a href="#" target="_self" class="icon-twitter" title="Twitter" style="color: #77c14e;"></a></li>
											<li><a href="#" target="_self" class="icon-facebook" title="Facebook" style="color: #3598cf;"></a></li>
										</ul>
									</div>
									<div class="col-sm-7">
										<div class="custom contact-details">
											<p style="margin-bottom: 10px;">
												<strong>Tél.: +212 606-383-858</strong><br>
												<strong>Tél.: +212 668-311-925</strong><br>
												<strong>Fax.: +212 522-382-873</strong><br>
												<strong>Email:&nbsp;<a href="mailto:pnsmaroc@gmail.com" style="color: #3598cf;font-weight: bold;">pnsmaroc@gmail.com</a></strong>
											</p>
											<p>
											  <strong>Adresse:</strong><br>46, BD zerktouni Etage 6 Casablanca Maroc
											</p>
										</div>									
									</div>
								</div>
								<div class="row">
								<p style="text-align: justify;">
                    PNS est une <strong>société</strong> spécialisé dans le <strong>nettoyage à Casablanca</strong>, la vente des produits de nettoyage et la vente des produits de dératisation.
                  
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="separator visible-xxs"></div>
          <div id="zn-res-menuwrapper">
            <a href="#" class="zn-res-trigger zn-header-icon"></a>
          </div>
          <div id="main-menu" class="main-nav zn_mega_wrapper " style="margin-left: 0px;">
            <ul id="menu-main-menu" class="main-menu zn_mega_menu">
            <li class="menu-item-has-children menu-item-mega-parent"><a href="http://societe-nettoyage-casablanca.com/" style="text-transform: uppercase;color:#FC0404;" >Accueil</a></li>
            <li class="menu-item-has-children"><a href="#" style="color: #FC0404 ;padding:5px 8px;font-size: 12px;">A propos de nous </a>
                <ul class="sub-menu clearfix">
                  <li><a href="societe-nettoyage-casablanca.html">Nettoyage Casablanca</a></li>
                  <li><a href="valeurs-nettoyage-casablanca.html">Nos Valeurs</a></li>
                  <li><a href="reference-nettoyage-casablanca.html">Nos Réferences</a></li>
                </ul>  
            </li>
            <li class="menu-item-has-children"><a href="#" style="color: #FC0404 ;padding:5px 8px;font-size: 12px;">Nos packs </a>
                <ul class="sub-menu clearfix">
                  <li><a href="nettoyage-particulier-casablanca.html">Nettoyage particulier</a></li>
                  <li><a href="nettoyage-professionnel-casablanca.html">Nettoyage professionnel</a></li>
                  <li><a href="femme-menage-casablanca.html">Femme de ménage</a></li>
                  
                </ul>  
            </li>

              <li class="menu-item-has-children"><a href="#" style="color: #FC0404;">Nos Services Nettoyage</a>
                <ul class="sub-menu clearfix">
                  <li><a href="nettoyage-bureaux-casablanca.html">Nettoyage Bureaux</a></li>
                  <li><a href="nettoyage-locaux-casablanca.html">Nettoyage locaux</a></li>
                  <li><a href="nettoyage-fin-chantier-casablanca.html">Nettoyage fin de chantier</a></li>
                  <li><a href="nettoyage-apres-travaux-casablanca.html">Nettoyage après travaux</a></li>
                  <li><a href="nettoyage-appartements-casablanca.html">Nettoyage appartements</a></li>
                  <li><a href="nettoyage-maisons-casablanca.html">Nettoyage maisons</a></li>
                  <li><a href="nettoyage-villas-casablanca.html">Nettoyage villas</a></li>
                  <li><a href="nettoyage-industriel-casablanca.html">Nettoyage industriel</a></li>
                  <li><a href="nettoyage-residences-casablanca.html">Nettoyage résidences</a></li>
                  <li><a href="nettoyage-hotels-casablanca.html">Nettoyage hôtels</a></li>
                  <li><a href="nettoyage-restaurants-casablanca.html">Nettoyage restaurants</a></li>
                  <li><a href="nettoyage-vitres-casablanca.html">Nettoyage vitres</a></li>
                  <li><a href="nettoyage-moquettes-casablanca.html">Nettoyage de moquettes</a></li>
                  <li><a href="nettoyage-parquet-casablanca.html">Nettoyage de parquets</a></li>
                </ul>
              </li> 
              <li class="menu-item-has-children"><a href="#" style="color: #FC0404;padding:5px 8px;font-size: 12px;">Entretien et rénovation</a>
                <ul class="sub-menu clearfix">
                    <li><a href="societe-nettoyage-entretien-sol-casablanca.html">Nettoyage de Sols</a></li>
                  <li><a href="societe-nettoyage-cristallisation-marbre-casablanca.html">Cristallisation du Marbre</a></li>
                  <li><a href="societe-nettoyage-poncage-parquet-casablanca.html">Ponçage du Parquet</a></li>
                  <li><a href="societe-nettoyage-moquette-casablanca-maroc.html">Entretien de Moquette</a></li>
                  <li><a href="societe-nettoyage-tapis-casablanca.html">Nettoyage des Tapis</a></li>
                  <li><a href="societe-nettoyage-canapes-casablanca.html">Nettoyage des Canapés</a></li>
                  <li><a href="societe-nettoyage-chaises-casablanca.html">Nettoyage des chaises</a></li>
                  <li><a href="societe-nettoyage-cristallisation-carrelage-casablanca.html">Nettoyage de Carrelage</a></li>
                  <li><a href="societe-nettoyage-cristallisation-mosaique-casablanca.html">Nettoyage de mosaïque</a></li>
                  <li><a href="societe-Nettoyage-Degraissage-hottes-casablanca.html">Hottes et Système d’extraction</a></li>
                  <li><a href="societe-nettoyage-ventilation-mecanique-casablanca.html">Ventilation Mécanique Contrôlée </a></li>
                </ul> 
            </li>
              <li class="menu-item-has-children"><a href="#" style="color: #FC0404;padding:5px 8px;font-size: 12px;">Produits</a>
      <ul class="sub-menu clearfix">
           <li><a href="produits-nettoyage-casablanca.html">Produits de Nettoyage</a></li>
           <li><a href="produits-deratisation-casablanca.html">Produits de Dératisation</a></li> 
      
      <li><a href="equipement-nettoyage-casablanca.html">Equipements</a></li>
          </ul>
        </li>
    <li class="menu-item-has-children"><a href="contact-casablanca.php" style="color: #FC0404;padding:5px 8px;font-size: 12px;">Contact</a></li>
            </ul>
          </div>
          <a href="contact-casablanca.php" id="ctabutton" class="ctabutton kl-cta-ribbon" style="left: -93px;" title="" target="_self"><strong>Devis</strong>en ligne<svg version="1.1" class="trisvg" xmlns="" x="0px" y="0px" preserveaspectratio="none" width="14px" height="5px" viewbox="0 0 14.017 5.006" enable-background="new 0 0 14.017 5.006" xml:space="preserve"><path fill-rule="evenodd" clip-rule="evenodd" d="M14.016,0L7.008,5.006L0,0H14.016z"></path></svg></a>
        </div>
      </header>

		        <div id="page_header" class="page-subheader site-subheader-cst uh_flat_dark_blue maskcontainer--mask3">
			<div class="bgback"></div>
			<div class="kl-bg-source">
				<div class="kl-bg-source__bgimage" style="background-image:url(images/contact.jpg); background-repeat:no-repeat; background-attachment:scroll; background-position-x:center; background-position-y:center; background-size:cover"></div>
				<div class="kl-bg-source__overlay"></div>
			</div>
			<div class="th-sparkles"></div>
			<div class="ph-content-wrap">
				<div class="ph-content-v-center">
					<div class="container">
						<div class="row">
							<div class="col-sm-6">
								<ul class="breadcrumbs fixclear">
									<li><a href="http://societe-nettoyage-casablanca.com/">ACCUEIL</a></li>
									<li><a href="contact-casablanca.php">Contact</a></li>
								</ul>
								
								<div class="clearfix"></div>
							</div>
							<div class="col-sm-6">
								
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="kl-bottommask kl-bottommask--mask3">
				<svg width="5000px" height="57px" class="svgmask " viewBox="0 0 5000 57">
					<defs>
						<filter x="-50%" y="-50%" width="200%" height="200%" filterUnits="objectBoundingBox" id="filter-mask3">
							<feOffset dx="0" dy="3" in="SourceAlpha" result="shadowOffsetInner1"></feOffset>
							<feGaussianBlur stdDeviation="2" in="shadowOffsetInner1" result="shadowBlurInner1"></feGaussianBlur>
							<feComposite in="shadowBlurInner1" in2="SourceAlpha" operator="arithmetic" k2="-1" k3="1" result="shadowInnerInner1"></feComposite>
							<feColorMatrix values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.4 0" in="shadowInnerInner1" type="matrix" result="shadowMatrixInner1"></feColorMatrix>
							<feMerge>
								<feMergeNode in="SourceGraphic"></feMergeNode>
								<feMergeNode in="shadowMatrixInner1"></feMergeNode>
							</feMerge>
						</filter>
					</defs>
					<path d="M9.09383679e-13,57.0005249 L9.09383679e-13,34.0075249 L2418,34.0075249 L2434,34.0075249 C2434,34.0075249 2441.89,33.2585249 2448,31.0245249 C2454.11,28.7905249 2479,11.0005249 2479,11.0005249 L2492,2.00052487 C2492,2.00052487 2495.121,-0.0374751261 2500,0.000524873861 C2505.267,-0.0294751261 2508,2.00052487 2508,2.00052487 L2521,11.0005249 C2521,11.0005249 2545.89,28.7905249 2552,31.0245249 C2558.11,33.2585249 2566,34.0075249 2566,34.0075249 L2582,34.0075249 L5000,34.0075249 L5000,57.0005249 L2500,57.0005249 L1148,57.0005249 L9.09383679e-13,57.0005249 Z" class="bmask-bgfill" filter="url(#filter-mask3)" fill="#f5f5f5"></path>
				</svg>
				<i class="glyphicon glyphicon-chevron-down"></i>
			</div>
		</div>
		<div class="kl-slideshow static-content__slideshow scontent__maps">
			<div class="th-google_map" style="height: 700px;">
    		</div>
    		<!-- end map -->

    		<!-- Google map content panel -->
    		<div class="kl-contentmaps__panel">
				<a href="#" class="js-toggle-class kl-contentmaps__panel-tgg hidden-xs" data-target=".kl-contentmaps__panel" data-target-class="is-closed"></a>
				<!-- Image & Image pop-up -->
				<a href="images/logo.png" data-lightbox="image" class="kl-contentmaps__panel-img" style="background-image:url(images/logo.png)"></a>

				<!-- Content -->
				<div class="kl-contentmaps__panel-info">
					<div class="kl-contentmaps__panel-info-text">
						<p>
							Societé de nettoyage PNS est une société spécialisé dans le nettoyage, l'hygiène 3D, la désinsectisation, la dératisation, la désinfection, le jardinage, et les travaux divers d'entretien.
						</p>
					</div>
				</div>
				<!--/ Content -->
			</div>
			<!-- Google map content panel -->
		</div>
	<section class="hg_section bg-white ptop-65">
			<div class="container">
				<div class="row">
					<div class="col-md-20 col-sm-20">
						<!-- Title element with bottom line and sub-title with custom paddings -->
						<div class="kl-title-block clearfix tbk--left tbk-symbol--line tbk-icon-pos--after-title ptop-35 pbottom-65">
							<!-- Title with custom montserrat font, size and black color -->
							<h2 class="tbk__title montserrat fs-34 black"><strong style="text-transform: uppercase;">CONTACT INFO</strong></h2>

							<!-- Title bottom symbol -->
							<div class="tbk__symbol ">
								<span></span>
							</div>
							<!--/ Title bottom symbol -->

							<!-- Sub-title with custom font size and thin style -->
							
						<!--/ Title element with bottom line and sub-title -->
					</div>
					<!--/ col-md-12 col-sm-12 -->
					<div class="container-sld">
						<div class="row">
							<div class="col-sm-4">
								 <h4>46, BD zerktouni Etage 6 Casablanca Maroc</h4>
							<p>
								Phone : +212 668 31 19 25<br>
								Fixe : +212 606 38 38 58
							</p>
							<p>
								<a href="mailto:#">pnsmaroc@gmail.com</a><br>
								<a href="http://societe-nettoyage-casablanca.com/">https://societe-nettoyage-casablanca.com/</a>
							</p>

   </div>
    
<div class="col-sm-8">
	<form id="contact-form" name="contact-form" method="post" >
      <h1>Contactez-nous</h1>
      <div class="separation"></div>
      <div class="corps-formulaire">
        <div class="gauche">
          <div class="groupe">
            <label>Votre Nom & Prénom</label>
            <input type="text" name="nom"autocomplete="off" />
            <i class="fas fa-user"></i>
          </div>
          <div class="groupe">
            <label>Votre adresse e-mail</label>
            <input type="text" name="email" id=email autocomplete="off" />
            <i class="fas fa-envelope"></i>
          </div>
          <div class="groupe">
            <label>Votre téléphone</label>
            <input type="text"name="tel" autocomplete="off" />
            <i class="fas fa-mobile"></i>
          </div>
          <div class="groupe">
            <label>Ville</label>
            <input type="text"name="ville" autocomplete="off" />
            <i class="fas fa-house-user"></i>
          </div>
          <div class="groupe">
            <label>Sujet</label>
            <input type="text" name="sujet" autocomplete="off" />
            <i class="fas fa-pen"></i>
          </div>
        </div>

        <div class="droite">
          <div class="groupe">
            <label>Message</label>
            <textarea name="message" placeholder="Saisissez ici..."></textarea>
          </div>
        </div>
      </div>

      <div class="pied-formulaire" align="center">
        <input type="submit" name="submit" value="Envoyer le message">
      </div>
    </form>
							    
							    
							</div>	
						</div>
				    </div>		
            <br /><br />

					
					
				</div>
				<!--/ row -->
				
			</div>

		</section>

	<footer id="footer">
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<h3 class="title m_title" style="color: #023EFB;"><strong><u>NOS SERVICES</u></strong></h3>
<p>-<a href="nettoyage-particulier-casablanca.html"> Nettoyage pour les particuliers</a></p>
<p>- <a href="nettoyage-professionnel-casablanca.html">Nettoyage pour les professionnels</a></p>
<p>- <a href="nettoyage-fin-chantier-casablanca.html">Nettoyage fin de chantier Casablanca</a></p>
<p>-<a href="nettoyage-industriel-casablanca.html"> Nettoyage industriel Casablanca</a></p>
<p>-<a href="nettoyage-moquettes-casablanca.html"> Nettoyage de moquette Casablanca</a></p>
<p>-<a href="societe-nettoyage-poncage-parquet-casablanca.html"> Nettoyage du parquet Casablanca</a></p>
<p>-<a href="nettoyage-vitres-casablanca.html"> Nettoyage des vitres Casablanca</a></p>
<p>-<a href="societe-nettoyage-cristallisation-marbre-casablanca.html"> Cristallisation du marbre Casablanca </a></p>

</div>

<div class="col-sm-4">
<div class="newsletter-signup">
<h3 class="title m_title" style="color: #023EFB;"><strong><u>Société de nettoyage à Casablanca</u></strong></h3>

<p> Notre société de <strong>nettoyage sur Casablanca</strong> attache une grande importance à l’image de vos locaux et un vrai savoir-faire dans le secteur du <em>nettoyage</em> et <strong>le ménage</strong> pour cela nous vous offrons des services de qualité et des prix attractifs, par un nombre de sites partout au Maroc.</p>
<br>
<h3 class="title m_title" style="color: #023EFB;"><strong><u>Notre site web</u></strong></h3>
<p>-<a href="http://societe-nettoyage-casablanca.com/"> Accueil</a></p>
<p>-<a href="contact-casablanca.php"> Devis en ligne</a></p>
<p>-<a href="produits-nettoyage-casablanca.html"> Produits de Nettoyage</a></p>



<div id="notification_container"></div>
</div>
</div>

<div class="col-sm-4">
<div>
<h3 class="title m_title"> CONTACT</h3>


<div class="contact-details">
<strong>Mobile : +212 668 31 19 25</strong><br />
<strong>Fixe : +212 606 38 38 58</strong><br />
<strong>Fax : +212 522 38 82 38 </strong><br />
<strong>Adresse 1 : 46 BD Zarktouni, 6éme ETG Casablanca.  </strong><br />
<strong>Adresse 2 : Rue Ahmed Touki N° 7 étage 2 Casablanca.  </strong><br />
<strong>Adresse 3 : 10 Rue ghandi R202  Rabat. </strong><br />
<strong>Email: <a href="contact-casablanca.html">pnsmaroc@gmail.com </a> </strong><br />
						<br>
 <a href="societe-nettoyage-entretien-sol-casablanca.html">Nettoyage de Sols</a>
                  <a href="societe-nettoyage-cristallisation-marbre-casablanca.html">Cristallisation du Marbre - </a>
                 
                  <a href="societe-nettoyage-tapis-casablanca.html">Nettoyage des Tapis - </a>
                  <a href="societe-nettoyage-canapes-casablanca.html">Nettoyage des Canapés - </a>
                  <a href="societe-nettoyage-chaises-casablanca.html">Nettoyage des chaises - </a>
                  <a href="societe-nettoyage-cristallisation-carrelage-casablanca.html">Nettoyage de Carrelage - </a>
                  <a href="societe-nettoyage-cristallisation-mosaique-casablanca.html">Nettoyage de mosaïque - </a>
                  <a href="societe-Nettoyage-Degraissage-hottes-casablanca.html">Hottes et Système d’extraction - </a>
                  <a href="societe-nettoyage-ventilation-mecanique-casablanca.html">Ventilation Mécanique Contrôlée -  </a><a href="femme-menage-casablanca.html">Femme de ménage</a> - <a href="nettoyage-bureaux-casablanca.html">Nettoyage Bureaux</a>	
							
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<div class="bottom clearfix">
							<ul class="social-icons sc--clean clearfix">
								<li><a href="#" target="_self" class="icon-facebook" title="Facebook"></a></li>
								<li><a href="#" target="_self" class="icon-twitter" title="Twitter"></a></li>	
								<li><a href="#" target="_self" class="icon-dribbble" title="Dribbble"></a></li>
								<li><a href="#" target="_blank" class="icon-google" title="Google Plus"></a></li>
							</ul>
							<div class="copyright">
								<p>© 2018. Buy <a href="http://societe-nettoyage-casablanca.com/">PNS</a>.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
	</div>
	
	<div class="bubble-box notification-box bg-purple" data-reveal-at="1200" data-hide-after="9000">
		<div class="bb--inner">
			<p>This is just a simple notice. Everything is in order and this is a <a href="#">simple link.</a></p>
		</div>
		<span class="bb--close"><i class="glyphicon glyphicon-remove"></i></span>
	</div>
	<div id="login_panel" class="mfp-hide loginbox-popup auth-popup">
		<div class="inner-container login-panel auth-popup-panel">
			<h3 class="m_title m_title_ext text-custom auth-popup-title tcolor">Connectez-vous à votre compte ECOSIN.</h3>
		
			<form class="login_panel" name="login_form" method="post" action="#">
				<div class="form-group kl-fancy-form">
					<input type="text" id="kl-username" name="log" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="eg: james_smith">
					<label class="kl-font-alt kl-fancy-form-label">NOM D'UTILISATEUR</label>
				</div>
				<div class="form-group kl-fancy-form">
					<input type="password" id="kl-password" name="pwd" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="type password">
					<label class="kl-font-alt kl-fancy-form-label">MOT DE PASSE</label>
				</div>
				<label class="auth-popup-remember" for="kl-rememberme"><input type="checkbox" name="rememberme" id="kl-rememberme" value="forever" class="auth-popup-remember-chb"> Souviens-toi de moi</label>
				<input type="submit" id="login" name="submit_button" class="btn zn_sub_button btn-fullcolor btn-md" value="LOG IN">
				<input type="hidden" value="login" class="" name="form_action"><input type="hidden" value="login" class="" name="action">
				<input type="hidden" value="#" class="" name="submit">
				<div class="links auth-popup-links">
					<a href="#register_panel" class="create_account auth-popup-createacc kl-login-box auth-popup-link">CRÉER UN COMPTE</a><span class="sep auth-popup-sep"></span><a href="#forgot_panel" class="kl-login-box auth-popup-link">MOT DE PASSE OUBLIÉ?</a>
				</div>
			</form>
		</div>
		<button title="Close (Esc)" type="button" class="mfp-close">×</button>
	</div>
	<div id="register_panel" class="mfp-hide loginbox-popup auth-popup">
		<div class="inner-container register-panel auth-popup-panel">
			<h3 class="m_title m_title_ext text-custom auth-popup-title">CRÉER UN COMPTE/h3>
			<form class="register_panel" name="login_form" method="post" action="#">
				<div class="form-group kl-fancy-form ">
					<input type="text" id="reg-username" name="user_login" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="type desired username"><label class="kl-font-alt kl-fancy-form-label">NOM D'UTILISATEUR</label>
				</div>
				<div class="form-group kl-fancy-form">
					<input type="text" id="reg-email" name="user_email" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="your-email@website.com"><label class="kl-font-alt kl-fancy-form-label">EMAIL</label>
				</div>
				<div class="form-group kl-fancy-form">
					<input type="password" id="reg-pass" name="user_password" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="*****"><label class="kl-font-alt kl-fancy-form-label">MOT DE PASSE</label>
				</div>
				<div class="form-group kl-fancy-form">
					<input type="password" id="reg-pass2" name="user_password2" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="*****"><label class="kl-font-alt kl-fancy-form-label">CONFIRMEZ LE MOT DE PASSE</label>
				</div>
				<div class="form-group">
					<input type="submit" id="signup" name="submit" class="btn zn_sub_button btn-block btn-fullcolor btn-md" value="CREATE MY ACCOUNT">
				</div>
				<div class="links auth-popup-links">
					<a href="#login_panel" class="kl-login-box auth-popup-link">VOUS AVEZ DÉJÀ UN COMPTE?</a>
				</div>
			</form>
		</div>
	</div>
	<div id="forgot_panel" class="mfp-hide loginbox-popup auth-popup forgot-popup">
		<div class="inner-container forgot-panel auth-popup-panel">
			<h3 class="m_title m_title_ext text-custom auth-popup-title">OUBLIEZ VOS DETAILS?</h3>
			<form class="forgot_form" name="login_form" method="post" action="#">
				<div class="form-group kl-fancy-form">
					<input type="text" id="forgot-email" name="user_login" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="...">
					<label class="kl-font-alt kl-fancy-form-label">NOM D'UTILISATEUR OU EMAIL</label>
				</div>
				<div class="form-group">
					<input type="submit" id="recover" name="submit" class="btn btn-block zn_sub_button btn-fullcolor btn-md" value="ENVOYER MES DONNÉES!">
				</div>
				<div class="links auth-popup-links">
					<a href="#login_panel" class="kl-login-box auth-popup-link">AAH, attendre, je me souviens maintenant!</a>
				</div>
			</form>
		</div>
		<button title="Close (Esc)" type="button" class="mfp-close">×</button>
	</div>
	<a href="#" id="totop">TOP</a>
	<script type="text/javascript" src="jas/bootstrap.min.js"></script>
	<script type=text/javascript src="js/plugins/jquery/jquery.min.js"></script>
	<script type=text/javascript src="js/plugins/jquery/jquery-ui.min.js"></script>
	<script type="text/javascript" src="jas/kl-plugins.js"></script>
	<script type="text/javascript" src="jas/plugins/scrollme/jquery.scrollme.js"></script>
	<script type="text/javascript" src="jas/plugins/_sliders/ios/jquery.iosslider.min.js"></script>
	<script type="text/javascript" src="jas/trigger/slider/ios/kl-ios-slider.js"></script>
	<script type="text/javascript" src="jas/plugins/_sliders/caroufredsel/jquery.carouFredSel-packed.js"></script>
	<script type="text/javascript" src="jas/trigger/kl-screenshot-box.js"></script>
	<script type="text/javascript" src="jas/trigger/kl-partners-carousel.js"></script>	
	<script type="text/javascript" src="jas/trigger/kl-recent-work-carousel.js"></script>
	<script type="text/javascript" src="jas/trigger/kl-recent-work-carousel2.js"></script>
	<script type="text/javascript" src="jas/trigger/kl-recent-work-carousel3.js"></script>
	<script type="text/javascript" src="jas/kl-scripts.js"></script>

	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDBjZXbwW4OLcTZtTo4Usl7SMI6sLZfATU"></script>
	<script type="text/javascript" src="jas/plugins/jquery.gmap.min.js"></script>
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-122728533-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-122728533-1');
</script>

	<script type="text/javascript">
		;(function($){
	"use strict";

	$(document).ready(function() {

		/*
		Find the Latitude and Longitude of your address:
			- http://itouchmap.com/latlong.html
			- http://universimmedia.pagesperso-orange.fr/geo/loc.htm
			- http://www.findlatitudeandlongitude.com/find-address-from-latitude-and-longitude/

		Find settings explained:
			- https://github.com/marioestrada/jQuery-gMap

		*/

		// Map Markers
		var mapMarkers = [{
			address: "Rue de la libérté 3 éme etage N 6 Casablanca",
			latitude: 33.586279,
			longitude: -7.6123045,
			icon: {
				image: "images/map-marker.png",
				iconsize: [60, 70], // w, h
				iconanchor: [60, 70] // x, y
			}
		}];

		// Map Color Scheme - more styles here http://snazzymaps.com/
		var mapStyles = [
			{
				"featureType": "water",
				"stylers": [
					{
						"visibility": "on"
					},
					{
						"color": "#acbcc9"
					}
				]
			},
			{
				"featureType": "landscape",
				"stylers": [
					{
						"color": "#f2e5d4"
					}
				]
			},
			{
				"featureType": "road.highway",
				"elementType": "geometry",
				"stylers": [
					{
						"color": "#c5c6c6"
					}
				]
			},
			{
				"featureType": "road.arterial",
				"elementType": "geometry",
				"stylers": [
					{
						"color": "#e4d7c6"
					}
				]
			},
			{
				"featureType": "road.local",
				"elementType": "geometry",
				"stylers": [
					{
						"color": "#fbfaf7"
					}
				]
			},
			{
				"featureType": "poi.park",
				"elementType": "geometry",
				"stylers": [
					{
						"color": "#c5dac6"
					}
				]
			},
			{
				"featureType": "administrative",
				"stylers": [
					{
						"visibility": "on"
					},
					{
						"lightness": 33
					}
				]
			},
			{
				"featureType": "road"
			},
			{
				"featureType": "poi.park",
				"elementType": "labels",
				"stylers": [
					{
						"visibility": "on"
					},
					{
						"lightness": 20
					}
				]
			},
			{},
			{
				"featureType": "road",
				"stylers": [
					{
						"lightness": 20
					}
				]
			}
		];

		// Map Initial Location
		var initLatitude = 33.586279;
		var initLongitude = -7.6123045;

		// Map Extended Settings
		var map = jQuery(".th-google_map").gMap({
			controls: {
				panControl: true,
				zoomControl: true,
				mapTypeControl: true,
				scaleControl: true,
				streetViewControl: true,
				overviewMapControl: true
			},
			scrollwheel: false,
			markers: mapMarkers,
			latitude: initLatitude,
			longitude: initLongitude,
			zoom: 14,
			style: mapStyles,
			draggable: Modernizr.touch ? false : true

		});

	});// end of document ready

})(jQuery);
	</script>
</body>

</html>

