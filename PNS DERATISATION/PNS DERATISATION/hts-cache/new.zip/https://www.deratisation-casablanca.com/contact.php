    
<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
   <head>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-53772008-1', 'auto');
  ga('send', 'pageview');

</script>


      <meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 

      <title>Devis de dératisation à Casablanca gratuit</title>
      <meta name="description" content="Devis gratuit.">
      <META HTTP-equiv="Pragma" CONTENT="no-cache"> 
<META NAME="Rating" CONTENT="general"> 
<META NAME="robots" CONTENT="ALL"> 
<META NAME="copyright" CONTENT="Copyright © 2013">
      <!-- Mobile Metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!-- Google Fonts  -->
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
      <link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
      <!-- Library CSS -->
      <link rel="stylesheet" href="css/bootstrap.css">
      <link rel="stylesheet" href="css/fonts/font-awesome/css/font-awesome.css">
      <link rel="stylesheet" href="css/animations.css" media="screen">
      <link rel="stylesheet" href="css/superfish.css" media="screen">
      <link rel="stylesheet" href="css/prettyPhoto.css" media="screen">
        <link rel="stylesheet" href="style.css.contact" />
      <!-- Theme CSS -->
      <link rel="stylesheet" href="css/style.css">
      
      <!-- Skin -->
      <link rel="stylesheet" href="css/colors/blue.css" id="colors">
    
      <!-- Responsive CSS -->
      <link rel="stylesheet" href="css/theme-responsive.css">
      <!-- Switcher CSS -->
     <link href="css/switcher.css" rel="stylesheet">
     <link href="css/spectrum.css" rel="stylesheet">
      <!-- Favicons -->
      <link rel="shortcut icon" href="img/ico/favicon.ico">
      <link rel="apple-touch-icon" href="img/ico/apple-touch-icon.png">
      <link rel="apple-touch-icon" sizes="72x72" href="img/ico/apple-touch-icon-72.png">
      <link rel="apple-touch-icon" sizes="114x114" href="img/ico/apple-touch-icon-114.png">
      <link rel="apple-touch-icon" sizes="144x144" href="img/ico/apple-touch-icon-144.png">
      <!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
      <!--[if lt IE 9]>
      <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <script src="js/respond.min.js"></script>
      <![endif]-->
      <!--[if IE]>
      <link rel="stylesheet" href="css/ie.css">
      <![endif]-->
   </head>
   <body class="blog">
      <div class="wrap">
         <!-- Header Start -->
         <header id="header">
            <!-- Header Top Bar Start -->
            <div class="top-bar">
               <div class="slidedown collapse">
                  <div class="container">
                     <div class="phone-email pull-left">
                        <a><i class="icon-phone"></i> télé: +212 699 08 99 00</a>
                        <a href="pixmamaroc@gmail.com"><i class="icon-envelope"></i> Email :pnsmaroc@gmail.com  </a>
                     </div>
                     <div class="pull-right">
                        <ul class="social pull-left">
                           <li class="facebook"><a href="#"><i class="icon-facebook"></i></a></li>
                           <li class="twitter"><a href="#"><i class="icon-twitter"></i></a></li>
                           <li class="dribbble"><a href="#"><i class="icon-dribbble"></i></a></li>
                           <li class="linkedin"><a href="#"><i class="icon-linkedin"></i></a></li>
                           <li class="rss"><a href="#"><i class="icon-rss"></i></a></li>
                        </ul>
                        <div id="search-form" class="pull-right">
                           <form action="#" method="get">
                              <input type="text" class="search-text-box">
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- Header Top Bar End -->
            <!-- Main Header Start -->
            <div class="main-header">
               <div class="container">
                  <!-- TopNav Start -->
                  <div class="topnav navbar-header">
                     <a class="navbar-toggle down-button" data-toggle="collapse" data-target=".slidedown">
                     <i class="icon-angle-down icon-current"></i>
                     </a> 
                  </div>
                  <!-- TopNav End -->
                  <!-- Logo Start -->
                  <div class="logo pull-left">
                     
                        
                        <img alt="Société de dératisation casablanca" height="86" src="img/logo.png" width="125" />
                        
                     
                  </div>
                  <!-- Logo End -->
                  <!-- Mobile Menu Start -->
                  <div class="mobile navbar-header">
                     <a class="navbar-toggle" data-toggle="collapse" href=".html">
                     <i class="icon-reorder icon-2x"></i>
                     </a> 
                  </div>
                  <!-- Mobile Menu End -->
                  <!-- Menu Start -->
                  <nav class="collapse navbar-collapse menu">
                     <ul class="nav navbar-nav sf-menu">
                        <li>
                           <a href="http://deratisation-casablanca.com/" class="sf-with-ul">
                           Accueil
                           <span class="sf-sub-indicator">
                           
                           </span>
                           </a>
                          
                        </li>
                        <li>
                           <a href="societe-de-deratisation-casablanca.html" class="sf-with-ul">
                           Dératisation
                           <span class="sf-sub-indicator">
                           
                           </span>
                           </a>
                          
                       </li>
                        <li>
                           <a href="desinsectisation-casablanca.html" class="sf-with-ul">
                           Désinsectisation
                           <span class="sf-sub-indicator">
                           
                           </span>
                           </a>
                          
                       </li>
                        <li>
                           <a href="societe-desinfection-casablanca.html" class="sf-with-ul">
                           Désinfection
                           <span class="sf-sub-indicator">
                           
                           </span>
                           </a>
                          
                       </li>
                       <li>
                                <a href="#">Nos services</a>
                                <ul>
                                    <li><a href="anti-souris-casablanca.html">Anti souris</a></li>
                                    <li><a href="anti-cafards-casablanca.html">Anti cafards et blattes</a></li>
                                    <li><a href="anti-fourmis-casablanca.html">Anti fourmis</a></li>
                                    <li><a href="traitement-anti-puces-casablanca.html">Anti puces</a></li>
                                    <li><a href="traitement-anti-punaises-de-lit-casablanca.html">Anti punaises de lit</a></li>
                                    <li><a href="anti-mouches-casablanca.html">Anti mouches</a></li>
                                    <li><a href="anti-moustiques-casablanca.html">Anti moustiques</a></li>
                                    <li><a href="anti-scorpions-casablanca.html">Anti scorpion</a></li>
                                    <li><a href="anti-serpents-casablanca.html">Anti serpent</a></li>
                                    <li><a href="anti-pigeons-casablanca.html">Anti pigeon </a></li>

                                    
                                </ul>
                            </li>
                        <li><a id="current" href="contact.html">Contact</a></li>
                     </ul>
                  </nav>
                  <!-- Menu End --> 
               </div>
            </div>
            <!-- Main Header End -->
         </header>
         <!-- Header End -->  
         <!-- Content Start -->
         <div id="main">
            <!-- Title, Breadcrumb Start-->
            <div class="breadcrumb-wrapper">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">
                        <h2 class="title">Contact</h2>
                     </div>
                     
                  </div>
               </div>
            </div>
            <!-- Title, Breadcrumb End-->
            <!-- Main Content start-->
            <div class="content">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12" id="contact-form">
                        <h3 class="title">DEVIS GRATUIT</h3>
                        <p>
                           Pour plus d'informations, un devis gratuit, une question sur nos compétences
ou sur nos traitements de désinsectisation, dératisation, désinfection, déreptilisation et 
à casablanca et partout au maroc, n'hésitez pas à nous contacter, notre équipe est à votre disposition.

Nous prendrons contact avec vous dès réception de votre message
                        </p>
                        <p>
                           N'hésitez pas à nous contacter pour un devis personnalisé gratuit.
                        </p>
                        <div class="col-sm-8">
	<form id="contact-form" name="contact-form" method="post" >
      <h1>Contactez-nous</h1>
      <div class="separation"></div>
      <div class="corps-formulaire">
        <div class="gauche">
          <div class="groupe">
            <label>Votre Nom & Prénom</label>
            <input type="text" name="nom"autocomplete="off" />
            <i class="fas fa-user"></i>
          </div>
          <div class="groupe">
            <label>Votre adresse e-mail</label>
            <input type="text" name="email" id=email autocomplete="off" />
            <i class="fas fa-envelope"></i>
          </div>
          <div class="groupe">
            <label>Votre téléphone</label>
            <input type="text"name="tel" autocomplete="off" />
            <i class="fas fa-mobile"></i>
          </div>
          <div class="groupe">
            <label>Ville</label>
            <input type="text"name="ville" autocomplete="off" />
            <i class="fas fa-house-user"></i>
          </div>
          <div class="groupe">
            <label>Sujet</label>
            <input type="text" name="sujet" autocomplete="off" />
            <i class="fas fa-pen"></i>
          </div>
        </div>

        <div class="droite">
          <div class="groupe">
            <label>Message</label>
            <textarea name="message" placeholder="Saisissez ici..."></textarea>
          </div>
        </div>
      </div>
      <div class="pied-formulaire" align="center">
        <input type="submit" name="submit" value="Envoyer le message">
      </div>
    </form>
							    
	</div>							
            
                        
                        
                        
                        
                        
                        
                        
                          
                     </div>
                     <div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
                        <div class="address widget">
                           <h3 class="title">Nos coordonnées </h3>
                           <ul class="contact-us">
                              <li>
                                 <i class="icon-map-marker"></i>
                                 <p>
                                    <strong>Addresse:</strong> 46, BD zerktouni Etage 6 Casablanca Maroc <br>
                                 </p>
                                 
                              </li>
                              <li>
                                 <i class="icon-phone"></i>
                                 <p>
                                    <strong>Téléphone:</strong>+212 699 08 99 00
                                 </p>
                              </li>
                              <li>
                                 <i class="icon-phone"></i>
                                 <p>
                                    <strong>Fixe:</strong>+212 606 38 38 58
                                 </p>
                              </li>
                              <li>
                                 <i class="icon-envelope"></i>
                                 <p>
                                    <strong>Email:</strong><a href="mailto:pnsmaroc@gmail.com">pnsmaroc@gmail.com </a>
                                 </p>
                              </li>
                           </ul>
                        </div>
                        <div class="contact-info widget">
                           <h3 class="title">Heures de travail</h3>
                           <ul>
                              <li><i class="icon-time"> </i>24H/24 et 7J/7</li>
                              
                           </ul>
                        </div>
                        <div class="follow widget">
                           <h4 class="title">Entreprise de dératisation à casablanca</h4>
                           <br> 
							<ul class="list1 pad_bot2">
							<li>Devis de dératisation à Casablanca</li> 
							<li>Devis de désinsectisation à Casablanca</li> 
							<li>Devis de désinfection à Casablanca</li> 
							<li> Devis d’hygiène 3d à Casablanca</li> 
								<li>Dératisation à casablanca</li> 
								<li>Désinsectisation à casablanca</li> 
								<li>Déreptilisation à casablanca</li> 
								<li>Désinfection à casablanca</li> 
								<li>Dépigeonnisation à casablanca</li> 
								<li>Anti cafard à casablanca</li> 
								<li>Anti souris à casablanca</li> 
								
								<li>Dératisation maisons à casablanca</li> 
								<li>Dératisation villas à casablanca</li> 
								<li>Dératisation bureaux à casablanca</li> 
								<li>Dératisation hôtels à casablanca</li> 
								<li>Dératisation immeubles à casablanca</li> 
								<li>Dératisation restaurants à casablanca</li> 
							
								
							</ul> 
							<br><br>
                        </div>
                     </div>
                  </div>
                  
                        <!-- Left Section End -->
                     </div>
                  </div>
                  <div class="divider"></div>
               </div>
            </div>
            <!-- Main Content end-->
         </div>
         <!-- Content End -->
        <!-- Footer Start -->
         <footer id="footer"><!-- Footer Top Start -->
<div class="footer-top">
<div class="container">
<div class="row">
<div class="col-md-3">
<div class="col">
<h4>Contact</h4>

<ul>
	<li>Adresse : 46 BD zerktouni etage 6 Casablanca Maroc</li>
	<li>Phone : +212 699 08 99 00</li>
	<li>Fixe : +212 606 38 38 58</li>
	<li>Email : <a href="contact.html" title="Email Us">pnsmaroc@gmail.com</a></li>
</ul>
</div>
</div>

<div class="col-md-2">
<div class="col">
<h4>Notre site web</h4>

<p></p>

<p><a href="https://www.deratisation-casablanca.com/"><il>- Accueil</il> </a></p>

<p><a href="plan-de-site.html"><il>- Plan de site</il> </a></p>

<p><a href="https://deratisationcasablanca.blogspot.com/"><il>- Blog</il> </a></p>

<p><a href="contact.html"><il>- Contact / Devis</il> </a></p>
<p><a href=""><il>- ONSSA Maroc</il> </a></p>
<p><a href=""><il>- Agroalimentaire</il> </a></p>

<ul>
</ul>

<p></p>
</div>
</div>

<div class="col-md-4">
<div class="col col-social-icons">


<ul><il><a href="https://www.deratisation-casablanca.com/">- Société de dératisation Casablanca Maroc</a></il>
	<li></li>
	<li><a href="desinsectisation-casablanca.html"><il> - Société de désinsectisation Casablanca Maroc</il> </a>
	<li></li>
	<li><a href="societe-de-deratisation-casablanca.html"><il> - Dératisation Casablanca Maroc</il> </a>
	<li></li>
	<li><a href="societe-de-deratisation-casablanca.html"><il> - Dératisation Maroc</il> </a>
	<li></li>
	<li><a href="desinsectisation-casablanca.html"><il> - Désinsectisation Casablanca Maroc</il> </a>
	<li></li>
	<li><a href="desinsectisation-casablanca.html"><il> - Désinsectisation Maroc</il> </a>
	<li></li>
	<a href="societe-desinfection-casablanca.html"> <il> - Désinfection Casablanca Maroc</il> </a>
	<li></li>
	<a href="societe-desinfection-casablanca.html"> <il> - Désinfection Maroc</il> </a>
	<li></li>
	<a href="dereptilisation-casablanca.html"> <il> - Déreptilisation à Casablanca</il> </a>
	<li></li>
	<a href="anti-pigeons-casablanca.html"> <il> - Anti pigeon Casablanca Maroc </il> </a>
	<li></li>
</ul>

<p></p>
</div>
</div>

<div class="col-md-3">
<div class="col">
    <ul><il><a href="anti-souris-casablanca.html">- Traitement rat Casablanca Maroc</a></il>
	<li></li>
	<li><a href="anti-souris-casablanca.html"><il> - Traitement souris Casablanca Maroc</il> </a>
	<li></li>
	<li><a href="anti-cafards-casablanca.html"><il> - Traitement cafards Casablanca Maroc</il> </a>
	<li></li>
	<li><a href="anti-fourmis-casablanca.html"><il> - Traitement fourmis Casablanca Maroc</il> </a>
	<li></li>
	<li><a href="traitement-anti-puces-casablanca.html"><il> - Traitement puces Casablanca Maroc</il> </a>
	<li></li>
	<li><a href="traitement-anti-punaises-de-lit-casablanca.html"><il> - Traitement punaise de lit Casablanca </il> </a>
	<li></li>
	<li><a href="anti-mouches-casablanca.html"><il> - Traitement mouche Casablanca Maroc</il> </a>
	<li></li>
	<a href="anti-moustiques-casablanca.html"> <il> - Traitement moustique Casablanca </il> </a>
	<li></li>
	<a href="anti-serpents-casablanca.html"> <il> - Traitement serpent Casablanca Maroc</il> </a>
	<li></li>
	<a href="anti-scorpions-casablanca.html"> <il> - Traitement scorpions Casablanca </il> </a>
	<li></li>
</ul>

</div>
</div>
</div>

<hr />
<div class="row">
<div class="col-lg-9 copyright">
&copy; Copyright 2014 - 2019 by <a href="www.deratisation-casablanca.com">Dératisation casablanca</a>. Tous droits réservés.</div> 
            <div class="col-lg-3 footer-logo"> 
            	
            </div> 
        </div> 
    </div> 
</div> 
            <!-- Footer Bottom End --> 
         </footer>
         
      
<!-- The Scripts -->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.js"></script>
      <script src="js/jquery.parallax.js"></script> 
      <script src="js/modernizr-2.6.2.min.js"></script> 
      <script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
      <script src="js/jquery.nivo.slider.pack.js"></script>
      <script src="js/jquery.prettyPhoto.js"></script>
      <script src="js/superfish.js"></script>
      <script src="js/tweetMachine.js"></script>
      <script src="js/tytabs.js"></script>
      <script src="js/jquery.sticky.js"></script>
      <script src="js/jflickrfeed.js"></script>
      <script src="js/imagesloaded.pkgd.min.js"></script>
      <script src="js/waypoints.min.js"></script>
      <script src="js/spectrum.js"></script>
      <script src="js/switcher.js"></script>
      <script src="http://maps.google.com/maps/api/js?sensor=false"></script>
      <script src="js/jquery.gmap.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>
                            
                            